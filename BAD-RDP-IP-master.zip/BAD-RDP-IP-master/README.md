# BAD-RDP-IP
Bad RDP IP´s from Brutforcers

This is a List of bad IP-Adresses from Bruteforcers.
You can import this list in your Firewall or security appliance.
This List will updated not automaticaly, i add the IP´s manualy.
